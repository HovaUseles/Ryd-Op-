﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;

namespace WMIApp
{
    class Manager
    {
        public string[,] CPUInfo()
        {
            CPU processor = new CPU();
            return processor.GetCoreUsage();
        }

        public string[,] UserInfoTest()
        {
            User pcUser = new User();
            return pcUser.GetUserInfo();

        }

        public void BootDeviceTest()
        {
            Console.WriteLine("---------------------------------------------------");
            ManagementScope scope = new ManagementScope("\\\\.\\ROOT\\cimv2");

            //create object query
            ObjectQuery query = new ObjectQuery("SELECT * FROM Win32_OperatingSystem");

            //create object searcher
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);

            //get a collection of WMI objects
            ManagementObjectCollection queryCollection = searcher.Get();

            //enumerate the collection.
            foreach (ManagementObject m in queryCollection)
            {
                // access properties of the WMI object
                Console.WriteLine("Boot Device : {0}", m["BootDevice"]);

            }
            Console.WriteLine("---------------------------------------------------");



        }

        public void MainStorage()
        {
            ObjectQuery wql = new ObjectQuery("SELECT * FROM Win32_OperatingSystem");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(wql);
            ManagementObjectCollection results = searcher.Get();

            foreach (ManagementObject result in results)
            {
                Console.WriteLine("Total Visible Memory: {0}KB", result["TotalVisibleMemorySize"]);
                Console.WriteLine("Free Physical Memory: {0}KB", result["FreePhysicalMemory"]);
                Console.WriteLine("Total Virtual Memory: {0}KB", result["TotalVirtualMemorySize"]);
                Console.WriteLine("Free Virtual Memory: {0}KB", result["FreeVirtualMemory"]);
            }

            Console.WriteLine("---------------------------------------------------");

        }


        public void GetDiskMetadata()
        {
            // Displays name and available space on drive
            ManagementScope managementScope = new ManagementScope();

            ObjectQuery objectQuery = new ObjectQuery("select FreeSpace,Size,Name from Win32_LogicalDisk where DriveType=3");

            ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(managementScope, objectQuery);

            ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();

            foreach (ManagementObject managementObject in managementObjectCollection)

            {

                Console.WriteLine("Disk Name : {0}", managementObject["Name"]);
                Console.WriteLine("FreeSpace : {0} gb", Convert.ToInt64(managementObject["FreeSpace"]) / (1024 * 1024 * 1024));
                Console.WriteLine("Disk Size : {0} gb", Convert.ToInt64(managementObject["Size"]) / (1024 * 1024 * 1024));

                Console.WriteLine("---------------------------------------------------");

            }

        }

        public void GetHardDiskSerialNumber(string drive = "C")

        {
            // Displays the C drive serial number
            ManagementObject managementObject = new ManagementObject("Win32_LogicalDisk.DeviceID=\"" + drive + ":\"");

            managementObject.Get();
            Console.WriteLine("Disk Serial Number: {0}", managementObject["VolumeSerialNumber"]);

            Console.WriteLine("---------------------------------------------------");


        }

        public void ListAllServices()
        {
            // Listing all running services

            Console.WriteLine("\nProcess search start\n");

            ManagementObjectSearcher windowsServicesSearcher = new ManagementObjectSearcher("root\\cimv2", "select * from Win32_Service");
            ManagementObjectCollection objectCollection = windowsServicesSearcher.Get();

            Console.WriteLine("---------------------------------------");
            Console.WriteLine("There are {0} Windows services: ", objectCollection.Count);
            Console.WriteLine("---------------------------------------");


            foreach (ManagementObject windowsService in objectCollection)
            {
                PropertyDataCollection serviceProperties = windowsService.Properties;
                foreach (PropertyData serviceProperty in serviceProperties)
                {
                    if (serviceProperty.Value != null)
                    {
                        Console.WriteLine("{0}, {1}", serviceProperty.Name, serviceProperty.Value);
                        //Console.WriteLine("Windows service property value: {0}", serviceProperty.Value);
                    }
                }
                Console.WriteLine("---------------------------------------");
            }
        }
    }
}

