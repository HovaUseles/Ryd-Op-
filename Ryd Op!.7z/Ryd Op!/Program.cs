﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;

namespace WMIApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager manager = new Manager();

            #region CPUinfo
            Console.WriteLine("Press any key to display CPU info");
            Console.ReadKey();
            string[,] cpuUse = manager.CPUInfo();
            for (int i = 0; i < cpuUse.GetLength(0); i++)
            {
                Console.WriteLine("CPU {0} : {1}", cpuUse[i, 0], cpuUse[i, 1]);
            }
            Console.WriteLine("---------------------------------------------------");
            #endregion

            #region User Info
            Console.WriteLine("Press any key to display User info");
            Console.ReadKey();
            string[,] userInfo = manager.UserInfoTest();
            for (int i = 0; i < userInfo.GetLength(0); i++)
            {
                Console.WriteLine("User:\t{0}", userInfo[i, 0]);
                Console.WriteLine("Org.:\t{0}", userInfo[i, 1]);
                Console.WriteLine("O/S :\t{0}", userInfo[i, 2]);
            }
            Console.WriteLine("---------------------------------------------------");
            #endregion

            manager.GetDiskMetadata();

            manager.GetHardDiskSerialNumber();

            manager.MainStorage();


            manager.BootDeviceTest();

            #region ListAllServices
            Console.WriteLine("Press any key to display all running services");
            Console.ReadKey();
            manager.ListAllServices();

            #endregion


            Console.ReadKey();

        } // End of Main


    }
}
